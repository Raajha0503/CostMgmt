import CMTAApp from "@/components/cmta-app"

export default function Page() {
  return (
    <div className="relative min-h-screen">
      <CMTAApp />
    </div>
  )
}
