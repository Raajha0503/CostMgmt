"use client"

import FirebaseExample from '../../components/firebase-example';

export default function FirebaseTestPage() {
  return <FirebaseExample />;
} 